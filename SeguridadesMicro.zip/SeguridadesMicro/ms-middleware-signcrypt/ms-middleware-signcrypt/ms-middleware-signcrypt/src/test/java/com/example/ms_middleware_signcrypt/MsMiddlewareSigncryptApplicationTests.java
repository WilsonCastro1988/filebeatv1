package com.example.ms_middleware_signcrypt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsMiddlewareSigncryptApplicationTests {

	@Test
	void contextLoads() {
	}

}
