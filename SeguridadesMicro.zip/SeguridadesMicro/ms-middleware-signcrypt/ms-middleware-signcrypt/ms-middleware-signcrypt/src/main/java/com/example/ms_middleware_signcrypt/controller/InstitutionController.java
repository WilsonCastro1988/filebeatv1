package com.example.ms_middleware_signcrypt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ms_middleware_signcrypt.model.Institutions;
import com.example.ms_middleware_signcrypt.service.IInstitutionService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/xml")
public class InstitutionController {
    
    @Autowired
    private IInstitutionService institutionService;

    @PostMapping("/getXml")
    public Institutions getXml(){
        institutionService.loadInstitutions();
        return institutionService.getInstitutions();
    }
}
