package com.example.ms_middleware_signcrypt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsMiddlewareSigncryptApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsMiddlewareSigncryptApplication.class, args);
	}

}
