package com.example.mtlsmock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtlsMockApplication {
    public static void main(String[] args) {
        SpringApplication.run(MtlsMockApplication.class, args);
    }
}
